<?php
session_start();

$permiso = $_SESSION['permiso'];

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <header class="nav-bg">
        <div class="nav-dv">
            <img src="IMG/DIRIS-Lima-Norte-300x49.png" alt="">

        </div>
    </header>
    <div class="div-gop">
        <img class="img-go" src="img/images.png" alt="" width="90">
    </div>

    <section class="botons">
        <div class="botons-div">
            <a class="boton" href="/reginven.php">Registro de inventario</a>
            <a class="boton" href="/docscaneados.php">Documentos escaneados</a>
        </div>
    </section>
    <section>
        <div>
            <?php if ($permiso == 1) { ?>
                <a class="boton" href="/docscaneados.php">Registrar usuario</a>
            <?php } ?>
        </div>
    </section>
</body>

</html>
<?php
$con = mysqli_connect("localhost", "root", "", "bd_diris");